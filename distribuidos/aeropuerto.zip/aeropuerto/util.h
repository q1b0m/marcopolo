#ifndef __UTIL_H__

double randRange(double min, double max);
void log_debug(char *msg);
void mostrar_estado_pistas(char * msg, int *estado_pistas, int num_pistas);

#define __UTIL_H__
#endif